/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interprete_D_Elementos;

public class ControlValor {
    public Object valor;
    public String tipo;
    
    public ControlValor(Object valor, String tipo){
        this.valor = valor;
        this.tipo = tipo;
    }

    public ControlValor() {
        
    }
    
}
